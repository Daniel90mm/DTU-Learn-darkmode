const CONFIG = {
  REJSEPLANEN_API_KEY: "fcf35b81-4431-4fe2-82f9-33fd33d02ecd"
};
